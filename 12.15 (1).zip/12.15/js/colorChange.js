$('body').click(function(){
    $('body').css('background','#' + bgColor());
});
function bgColor()
{
    return Math.floor(Math.random()*16777216).toString(16);
}